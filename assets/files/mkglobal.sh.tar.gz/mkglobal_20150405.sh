#!/bin/sh

rm -rf cscope.files cscope.files cscope.out ncscope.out cscope.in.out cscope.po.out ncscope.in.out ncscope.po.out
rm -rf global.files GTAGS GRTAGS GPATH

##find $PWD ! \( -type d \) \( \( -path $PWD/out -o -path \
#find $PWD  \( -path $PWD/out \
#-o -path '*.svn' \
#-o -path '*.repo' \
#-o -path '*.git' \
#-o -path '*.gitignore' \
#\) -prune -o \
#\
#\( -name '*.[cChHsS]' \
#-o -name '*.[hc]pp' \
#-o -name '*.[hc]xx' \
#-o -name '[mM]akefile*' \
#-o -name '*.api' \
#-o -name '*.dts[i]' \
#-o -name '*.cc' \
#-o -name '*.mk' \
#-o -name '*.sh' \
#-o -name '*types' \
#-o -name '*fstab' \
#-o -name '*aidl' \
#-o -name '[kK][cC]onfig' \
#-o -name '[kK][bB]uild*' \
#-o -name '*script*' \
#-o -name '*.conf' \
#-o -name '*.mak' \
#-o -name '*.min' \
#-o -name '*.cmm' \
#-o -name '*.txt' \
#-o -name '*Sconscript*' \
#-o -name 'scons' \
#-o -name '*.scon[s]' \
#-o -name '*config' \
#-o -name '*.rc' \
#-o -name '*.ld' \
#-o -name '*lds' \
#-o -name '*.java' \
#-o -name '*.cmd' \
#-o -name '*.pm' \
#-o -name '*.py' \
#-o -name '*.pl' \
#-o -name '*.lk' \
#-o -name '*.prop' \
#-o -name '*.kcm' \
#-o -name '*qcom' \
#-o -name '*.pds' \
#-o -name '*.cfg' \
#-o -name '*.scl' \
#-o -name '*_H' \
#-o -name '*.xml' \
#-o -name '*[sS][cC]onscript*' \
#-o -name '*[sS][cC]onstruct' \
#\)  -print > global.files
#
#gtags -f global.files
##cscope -q -b -k -i cscope.files
##cscope -b -k -i cscope.files
gtags
